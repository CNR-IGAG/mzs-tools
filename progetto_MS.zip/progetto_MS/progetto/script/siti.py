# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:		siti.py
# Author:	  Tarquini E.
# Created:	 07-12-2017
#-------------------------------------------------------------------------------

from qgis.core import *
from qgis.PyQt.QtWidgets import *
from PyQt4.QtGui import QFileDialog
import processing
import re


def siti_puntuali(dialog, layer, feature):

	quota_slm = dialog.findChild(QLineEdit,"quota_slm")
	data_sito = dialog.findChild(QDateTimeEdit,"data_sito")

	today = QtCore.QDate.currentDate()
	data_sito.setDate(today)
	quota_slm.textEdited.connect(lambda: update_valore(quota_slm))


def siti_lineari(dialog, layer, feature):

	aquota = dialog.findChild(QLineEdit,"aquota")
	bquota = dialog.findChild(QLineEdit,"bquota")
	data_sito = dialog.findChild(QDateTimeEdit,"data_sito")

	today = QtCore.QDate.currentDate()
	data_sito.setDate(today)
	aquota.textEdited.connect(lambda: update_valore(aquota))
	bquota.textEdited.connect(lambda: update_valore(bquota))


def update_valore(value):

	value.setText(re.sub('[^0-9.]','', value.text()))