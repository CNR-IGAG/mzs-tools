# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:		indagini.py
# Author:	  Tarquini E.
# Created:	 20-11-2017
#-------------------------------------------------------------------------------

from qgis.core import *
from qgis.PyQt.QtWidgets import *
from PyQt4.QtGui import QFileDialog
import re


def indagini_puntuali(dialog, layer, feature):

	codici_indagini = []
	lista_indagini = []
##	global classe_ind
	id_spu = dialog.findChild(QComboBox,"id_spu")
	tipo_ind_box = dialog.findChild(QComboBox,"tipo_ind_box")
	tipo_ind = dialog.findChild(QLineEdit,"tipo_ind")
	classe_ind = dialog.findChild(QComboBox,"classe_ind")
	doc_ind = dialog.findChild(QLineEdit,"doc_ind")
	button_doc = dialog.findChild(QPushButton,"pushButton")
	data_ind = dialog.findChild(QDateTimeEdit,"data_ind")
	prof_top = dialog.findChild(QLineEdit,"prof_top")
	prof_bot = dialog.findChild(QLineEdit,"prof_bot")
	quota_slm_top = dialog.findChild(QLineEdit,"quota_slm_top")
	quota_slm_bot = dialog.findChild(QLineEdit,"quota_slm_bot")
	buttonBox = dialog.findChild(QDialogButtonBox, "buttonBox")
	today = QtCore.QDate.currentDate()

	data_ind.setDate(today)
	buttonBox.setEnabled(False)
	define_tipo_ind_p(codici_indagini)
	classe_ind.currentIndexChanged.connect(lambda: update_box_ind_p(classe_ind,tipo_ind_box,codici_indagini))
	tipo_ind_box.currentIndexChanged.connect(lambda: update_tipo_ind_p(tipo_ind, tipo_ind_box))
	button_doc.clicked.connect(lambda: select_output_file(button_doc,doc_ind))
	tipo_ind_box.currentIndexChanged.connect(lambda: disableButton_p(tipo_ind_box, classe_ind, id_spu, buttonBox))
	classe_ind.currentIndexChanged.connect(lambda: disableButton_p(tipo_ind_box, classe_ind, id_spu, buttonBox))
	id_spu.currentIndexChanged.connect(lambda: disableButton_p(tipo_ind_box, classe_ind, id_spu, buttonBox))
	prof_top.textEdited.connect(lambda: update_valore(prof_top))
	prof_bot.textEdited.connect(lambda: update_valore(prof_bot))
	quota_slm_top.textEdited.connect(lambda: update_valore(quota_slm_top))
	quota_slm_bot.textEdited.connect(lambda: update_valore(quota_slm_bot))
	prof_bot.editingFinished.connect(lambda: alert_spessore(prof_top, prof_bot))
	prof_top.editingFinished.connect(lambda: alert_spessore(prof_top, prof_bot))
	quota_slm_top.editingFinished.connect(lambda: alert_spessore(quota_slm_top, quota_slm_bot))
	quota_slm_bot.editingFinished.connect(lambda: alert_spessore(quota_slm_top, quota_slm_bot))


def define_tipo_ind_p(codici_indagini):

	codici_indagini_layer = QgsMapLayerRegistry.instance().mapLayersByName("vw_tipo_ind_p")[0]

	for classe in codici_indagini_layer.getFeatures(QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)):
		lista_indagini=[classe.attributes()[1],classe.attributes()[2],classe.attributes()[3]]
		codici_indagini.append(lista_indagini)
	return codici_indagini


def update_tipo_ind_p(tipo_ind, tipo_ind_box):

	TipoIndagine = str(tipo_ind_box.currentText().strip()).split(" - ")[0]
	tipo_ind.setText(TipoIndagine)


def disableButton_p(input1, input2, input3, buttonBox):

	check_campi = [input1.currentText(), input2.currentText(), input3.currentText()]
	check_value = []

	for x in check_campi:
		if len(x) > 0:
			value_campi = 1
			check_value.append(value_campi)
		else:
			value_campi = 0
			check_value.append(value_campi)

	campi = sum(check_value)
	if campi > 2:
		buttonBox.setEnabled(True)
	else:
		buttonBox.setEnabled(False)


def update_box_ind_p(classe_ind,tipo_ind_box,codici_indagini):

	curIndex = str(classe_ind.currentText().strip()).split(" - ")[0]

	tipo_ind_box.clear()
	tipo_ind_box.addItem("")
	tipo_ind_box.model().item(0).setEnabled(False)
	for row in codici_indagini:
		if row[0]==curIndex:
			tipo_ind_box.addItem(row[2])


def indagini_lineari(dialog, layer, feature):

	codici_indagini = []
	lista_indagini = []
##	global classe_ind
	id_sln = dialog.findChild(QComboBox,"id_sln")
	tipo_ind_box = dialog.findChild(QComboBox,"tipo_ind_box")
	tipo_ind = dialog.findChild(QLineEdit,"tipo_ind")
	classe_ind = dialog.findChild(QComboBox,"classe_ind")
	doc_ind = dialog.findChild(QLineEdit,"doc_ind")
	button_doc = dialog.findChild(QPushButton,"pushButton")
	data_ind = dialog.findChild(QDateTimeEdit,"data_ind")
	alert_text = dialog.findChild(QLabel,"alert_text")
	alert_img = dialog.findChild(QLabel,"alert_img")
	buttonBox = dialog.findChild(QDialogButtonBox, "buttonBox")
	today = QtCore.QDate.currentDate()

	data_ind.setDate(today)
	buttonBox.setEnabled(False)
	alert_text.hide()
	alert_img.hide()
	define_tipo_ind_l(codici_indagini)
	classe_ind.currentIndexChanged.connect(lambda: update_box_ind_l(classe_ind,tipo_ind_box,codici_indagini))
	tipo_ind_box.currentIndexChanged.connect(lambda: update_tipo_ind_l(tipo_ind, tipo_ind_box,alert_text,alert_img,doc_ind,buttonBox, classe_ind, id_sln))
	classe_ind.currentIndexChanged.connect(lambda: update_tipo_ind_l(tipo_ind, tipo_ind_box,alert_text,alert_img,doc_ind,buttonBox, classe_ind, id_sln))
	id_sln.currentIndexChanged.connect(lambda: update_tipo_ind_l(tipo_ind, tipo_ind_box,alert_text,alert_img,doc_ind,buttonBox, classe_ind, id_sln))
	button_doc.clicked.connect(lambda: select_output_file(button_doc,doc_ind))
	doc_ind.textChanged.connect(lambda: document(doc_ind,buttonBox))


def define_tipo_ind_l(codici_indagini):

	codici_indagini_layer = QgsMapLayerRegistry.instance().mapLayersByName("vw_tipo_ind_l")[0]

	for classe in codici_indagini_layer.getFeatures(QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)):
		lista_indagini=[classe.attributes()[1],classe.attributes()[2],classe.attributes()[3]]
		codici_indagini.append(lista_indagini)
	return codici_indagini


def update_tipo_ind_l(tipo_ind, tipo_ind_box,alert_text,alert_img,doc_ind,buttonBox, classe_ind, id_sln):

	TipoIndagine = str(tipo_ind_box.currentText().strip()).split(" - ")[0]

	check_campi = [tipo_ind_box.currentText(), classe_ind.currentText(), id_sln.currentText()]
	check_value = []

	for x in check_campi:
		if len(x) > 0:
			value_campi = 1
			check_value.append(value_campi)
		else:
			value_campi = 0
			check_value.append(value_campi)

	campi = sum(check_value)
	tipo_ind.setText(TipoIndagine)

	if campi > 2:
		if tipo_ind.text() in ("ERT","PR","SEO","SEV","RAD","SL","SR","SGE","STP"):
			alert_text.show()
			alert_img.show()
			if len(doc_ind.text()) < 5:
				buttonBox.setEnabled(False)
			else:
				buttonBox.setEnabled(True)
		else:
			alert_text.hide()
			alert_img.hide()
			buttonBox.setEnabled(True)
	else:
		buttonBox.setEnabled(False)


def update_box_ind_l(classe_ind,tipo_ind_box,codici_indagini):

	curIndex = str(classe_ind.currentText().strip()).split(" - ")[0]

	tipo_ind_box.clear()
	tipo_ind_box.addItem("")
	tipo_ind_box.model().item(0).setEnabled(False)
	for row in codici_indagini:
		if row[0]==curIndex:
			tipo_ind_box.addItem(row[2])


def document(doc_ind,buttonBox):
	if len(doc_ind.text()) < 5:
		buttonBox.setEnabled(False)
	else:
		buttonBox.setEnabled(True)


def select_output_file(button_doc,doc_ind):

	doc_ind.clear()
	filedirectory = QFileDialog.getOpenFileName(button_doc, "Select output file ","", '*.pdf')
	drive, path_and_file = os.path.splitdrive(filedirectory)
	path, filename = os.path.split(path_and_file)
	doc_ind.setText(filename)


def update_valore(value):

	value.setText(re.sub('[^0-9.]','', value.text()))


def alert_spessore(value1, value2):

	if value2.text() == '':
		pass
	elif value1.text() == '':
		pass
	else:
		if float(value1.text()) > float(value2.text()):
			QMessageBox.warning(None, u'WARNING!', u"The value of the 'TOP' field is greater than the value of the 'BOTTOM' field!")
			value1.setText('')
			value2.setText('')