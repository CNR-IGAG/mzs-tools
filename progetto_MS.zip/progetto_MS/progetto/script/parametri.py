# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:		parametri.py
# Author:	  Tarquini E.
# Created:	 04-12-2017
#-------------------------------------------------------------------------------

from qgis.core import *
from qgis.PyQt.QtWidgets import *
import re


def parametri_puntuali(dialog, layer, feature):

	codici_parametri = []
	lista_parametri = []
	global tipo_parpu
	global tipo_parpu_box
	tipo_parpu_box = dialog.findChild(QComboBox,"tipo_parpu_box")
	tipo_parpu = dialog.findChild(QLineEdit,"tipo_parpu")
	id_indpu = dialog.findChild(QComboBox,"id_indpu")
	data_par = dialog.findChild(QDateTimeEdit,"data_par")
	prof_top = dialog.findChild(QLineEdit,"prof_top")
	prof_bot = dialog.findChild(QLineEdit,"prof_bot")
	quota_slm_top = dialog.findChild(QLineEdit,"quota_slm_top")
	quota_slm_bot = dialog.findChild(QLineEdit,"quota_slm_bot")
	buttonBox = dialog.findChild(QDialogButtonBox, "buttonBox")
	today = QtCore.QDate.currentDate()

	data_par.setDate(today)
	buttonBox.setEnabled(False)
	define_param_p(codici_parametri)

	if id_indpu.currentText() != '':
		id_indpu.currentIndexChanged.connect(lambda: update_param_p(codici_parametri, id_indpu, tipo_parpu_box))
		update_param_p(codici_parametri, id_indpu, tipo_parpu_box)
	else:
		id_indpu.currentIndexChanged.connect(lambda: update_param_p(codici_parametri, id_indpu, tipo_parpu_box))

	tipo_parpu_box.currentIndexChanged.connect(lambda: update_tipo_par_p(tipo_parpu, tipo_parpu_box))
	tipo_parpu_box.currentIndexChanged.connect(lambda: disableButton(tipo_parpu_box, buttonBox))
	prof_top.textEdited.connect(lambda: update_valore(prof_top))
	prof_bot.textEdited.connect(lambda: update_valore(prof_bot))
	quota_slm_top.textEdited.connect(lambda: update_valore(quota_slm_top))
	quota_slm_bot.textEdited.connect(lambda: update_valore(quota_slm_bot))
	prof_bot.editingFinished.connect(lambda: alert_spessore(prof_top, prof_bot))
	prof_top.editingFinished.connect(lambda: alert_spessore(prof_top, prof_bot))
	quota_slm_top.editingFinished.connect(lambda: alert_spessore(quota_slm_top, quota_slm_bot))
	quota_slm_bot.editingFinished.connect(lambda: alert_spessore(quota_slm_top, quota_slm_bot))


def define_param_p(codici_parametri):

	codici_parametri_layer = QgsMapLayerRegistry.instance().mapLayersByName("vw_param_p")[0]
	for param in codici_parametri_layer.getFeatures(QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)):
		lista_parametri=[param.attributes()[1],param.attributes()[2],param.attributes()[3]]
		codici_parametri.append(lista_parametri)
	return codici_parametri


def update_param_p(codici, id_indpu, tipo_parpu_box):

	curIndex = str(id_indpu.currentText().strip())[8:].strip("123456789")

	tipo_parpu_box.clear()
	tipo_parpu_box.addItem("")
	tipo_parpu_box.model().item(0).setEnabled(False)
	for row in codici:
		if id_indpu.currentText()[6:7] == 'P':
			if curIndex == str(row[0]):
				tipo_parpu_box.setEnabled(True)
				tipo_parpu_box.setCurrentIndex(0)
				tipo_parpu_box.addItem(row[2])


def update_tipo_par_p(tipo_parpu, tipo_parpu_box):

	if tipo_parpu_box.currentText() != '':
		TipoParametro = tipo_parpu_box.currentText().strip().split(" - ")[0]
		tipo_parpu.setText(TipoParametro)


def parametri_lineari(dialog, layer, feature):

	codici_parametri = []
	lista_parametri = []
	global tipo_parln
	global tipo_parln_box
	tipo_parln_box = dialog.findChild(QComboBox,"tipo_parln_box")
	tipo_parln = dialog.findChild(QLineEdit,"tipo_parln")
	id_indln = dialog.findChild(QComboBox,"id_indln")
	attend_mis = dialog.findChild(QComboBox,"attend_mis")
	data_par = dialog.findChild(QDateTimeEdit,"data_par")
	note_par = dialog.findChild(QTextEdit,"note_par")
	prof_bot = dialog.findChild(QLineEdit,"prof_bot")
	prof_top = dialog.findChild(QLineEdit,"prof_top")
	quota_slm_bot = dialog.findChild(QLineEdit,"quota_slm_bot")
	quota_slm_top = dialog.findChild(QLineEdit,"quota_slm_top")
	valore = dialog.findChild(QLineEdit,"valore")
	alert_text = dialog.findChild(QLabel,"alert_text")
	alert_img = dialog.findChild(QLabel,"alert_img")
	prof_top = dialog.findChild(QLineEdit,"prof_top")
	prof_bot = dialog.findChild(QLineEdit,"prof_bot")
	quota_slm_top = dialog.findChild(QLineEdit,"quota_slm_top")
	quota_slm_bot = dialog.findChild(QLineEdit,"quota_slm_bot")
	buttonBox = dialog.findChild(QDialogButtonBox, "buttonBox")
	today = QtCore.QDate.currentDate()

	data_par.setDate(today)
	buttonBox.setEnabled(False)
	alert_text.hide()
	alert_img.hide()
	attend_mis.addItem("")
	attend_mis.model().item(3).setEnabled(False)
	define_param_l(codici_parametri)

	if id_indln.currentText() != '':
		id_indln.currentIndexChanged.connect(lambda: update_param_l(codici_parametri, id_indln, tipo_parln_box, attend_mis, note_par, prof_bot, prof_top, quota_slm_bot, quota_slm_top, valore, data_par, alert_text, alert_img, buttonBox))
		update_param_l(codici_parametri, id_indln, tipo_parln_box, attend_mis, note_par, prof_bot, prof_top, quota_slm_bot, quota_slm_top, valore, data_par, alert_text, alert_img, buttonBox)
	else:
		id_indln.currentIndexChanged.connect(lambda: update_param_l(codici_parametri, id_indln, tipo_parln_box, attend_mis, note_par, prof_bot, prof_top, quota_slm_bot, quota_slm_top, valore, data_par, alert_text, alert_img, buttonBox))

	tipo_parln_box.currentIndexChanged.connect(lambda: update_tipo_par_l(tipo_parln, tipo_parln_box))
	tipo_parln_box.currentIndexChanged.connect(lambda: disableButton(tipo_parln_box, buttonBox))
	prof_top.textEdited.connect(lambda: update_valore(prof_top))
	prof_bot.textEdited.connect(lambda: update_valore(prof_bot))
	quota_slm_top.textEdited.connect(lambda: update_valore(quota_slm_top))
	quota_slm_bot.textEdited.connect(lambda: update_valore(quota_slm_bot))
	prof_bot.editingFinished.connect(lambda: alert_spessore(prof_top, prof_bot))
	prof_top.editingFinished.connect(lambda: alert_spessore(prof_top, prof_bot))
	quota_slm_top.editingFinished.connect(lambda: alert_spessore(quota_slm_top, quota_slm_bot))
	quota_slm_bot.editingFinished.connect(lambda: alert_spessore(quota_slm_top, quota_slm_bot))


def define_param_l(codici_parametri):

	codici_parametri_layer = QgsMapLayerRegistry.instance().mapLayersByName("vw_param_l")[0]
	for param in codici_parametri_layer.getFeatures(QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)):
		lista_parametri=[param.attributes()[1],param.attributes()[2],param.attributes()[3]]
		codici_parametri.append(lista_parametri)
	return codici_parametri


def update_param_l(codici, id_indln, tipo_parln_box, attend_mis, note_par, prof_bot, prof_top, quota_slm_bot, quota_slm_top, valore, data_par, alert_text, alert_img, buttonBox):

	curIndex = str(id_indln.currentText().strip())[8:].strip("123456789")
	today = QtCore.QDate.currentDate()

	tipo_parln_box.clear()
	tipo_parln_box.addItem("")
	tipo_parln_box.model().item(0).setEnabled(False)
	for row in codici:
		if id_indln.currentText()[6:7] == 'L':
			if curIndex in ("ERT","PR","SEO","SEV","RAD","SL","SR","SGE","STP"):
				alert_text.show()
				alert_img.show()
				buttonBox.setEnabled(False)
				tipo_parln_box.setEnabled(False)
				tipo_parln_box.setCurrentIndex(0)
				attend_mis.setEnabled(False)
				attend_mis.setCurrentIndex(4)
				data_par.setEnabled(False)
				data_par.setDate(today)
				note_par.setEnabled(False)
				note_par.setText('')
				prof_bot.setEnabled(False)
				prof_bot.setText('')
				prof_top.setEnabled(False)
				prof_top.setText('')
				quota_slm_bot.setEnabled(False)
				quota_slm_bot.setText('')
				quota_slm_top.setEnabled(False)
				quota_slm_top.setText('')
				valore.setEnabled(False)
				valore.setText('')
			else:
				if curIndex == str(row[0]):
					alert_text.hide()
					alert_img.hide()
					tipo_parln_box.setEnabled(True)
					tipo_parln_box.setCurrentIndex(0)
					tipo_parln_box.addItem(row[2])
					attend_mis.setEnabled(True)
					attend_mis.setCurrentIndex(4)
					data_par.setEnabled(True)
					data_par.setDate(today)
					note_par.setEnabled(True)
					note_par.setText('')
					prof_bot.setEnabled(True)
					prof_bot.setText('')
					prof_top.setEnabled(True)
					prof_top.setText('')
					quota_slm_bot.setEnabled(True)
					quota_slm_bot.setText('')
					quota_slm_top.setEnabled(True)
					quota_slm_top.setText('')
					valore.setEnabled(True)
					valore.setText('')


def update_tipo_par_l(tipo_parln, tipo_parln_box):

	if tipo_parln_box.currentText() != '':
		TipoParametro = tipo_parln_box.currentText().strip().split(" - ")[0]
		tipo_parln.setText(TipoParametro)


def disableButton(input1, buttonBox):

	if input1.currentText() == '':
		buttonBox.setEnabled(False)
	else:
		buttonBox.setEnabled(True)


def update_valore(value):

	value.setText(re.sub('[^0-9.]','', value.text()))


def alert_spessore(value1, value2):

	if value2.text() == '':
		pass
	elif value1.text() == '':
		pass
	else:
		if float(value1.text()) > float(value2.text()):
			QMessageBox.warning(None, u'WARNING!', u"The value of the 'TOP' field is greater than the value of the 'BOTTOM' field!")
			value1.setText('')
			value2.setText('')