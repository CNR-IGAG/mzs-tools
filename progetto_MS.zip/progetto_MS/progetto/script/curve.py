# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:		curve.py
# Author:	  Tarquini E.
# Created:	 22-06-2018
#-------------------------------------------------------------------------------

from qgis.core import *
from qgis.PyQt.QtWidgets import *
import re


def curve(dialog, layer, feature):

	id_parpu = dialog.findChild(QComboBox,"id_parpu")
	buttonBox = dialog.findChild(QDialogButtonBox, "buttonBox")
	cond_curve = dialog.findChild(QLineEdit,"cond_curve")
	varx = dialog.findChild(QLineEdit,"varx")
	vary = dialog.findChild(QLineEdit,"vary")

	buttonBox.setEnabled(False)

	cond_curve.textEdited.connect(lambda: update_valore(cond_curve))
	varx.textEdited.connect(lambda: update_valore(varx))
	vary.textEdited.connect(lambda: update_valore(vary))

	if id_parpu.currentText() != '':
		id_parpu.currentIndexChanged.connect(lambda: disableButton(id_parpu, buttonBox))
		disableButton(id_parpu, buttonBox)
	else:
		id_parpu.currentIndexChanged.connect(lambda: disableButton(id_parpu, buttonBox))


def disableButton(id_parpu,buttonBox):
	if len(id_parpu.currentText()) < 1:
		buttonBox.setEnabled(False)
	else:
		buttonBox.setEnabled(True)


def update_valore(value):

	value.setText(re.sub('[^0-9.]','', value.text()))